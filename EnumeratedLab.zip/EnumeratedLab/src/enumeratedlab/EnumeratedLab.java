package enumeratedlab;

// James Jensen

public class EnumeratedLab {

    public static void main(String[] args) {
        Book One = new Book("J.K. Rowling", "Harry Potter and the Sorcerer's Stone", Condition.FAIR);
        System.out.println(One.toString());
        Book Two = new Book("Stephanie Meyer", "Host", Condition.EXCELLENT);
        System.out.println(Two.toString());
        Book Three = new Book("Queen Elizabeth", "Magna Carta", Condition.POOR);
        System.out.println(Three.toString());

    }

}
