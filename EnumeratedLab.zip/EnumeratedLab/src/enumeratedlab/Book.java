package enumeratedlab;

// James Jensen

    enum Condition { EXCELLENT, VERY_GOOD, GOOD, FAIR, POOR }

public class Book {
    private Condition condition = Condition.EXCELLENT;
    private String author = "Nothing";
    private String title = "Nothing";
    
    public Book(String author, String title, Condition who) {
        this.author = author;
        this.title = title;
        this.condition = condition;
    }
    
    @Override
    public String toString() {
        return String.format("%s is written by %s and is in %s condition", author, title, condition);
    }
}
