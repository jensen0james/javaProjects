package classesobjects;

// Author James Jensen

import java.util.*;

public class ClassesObjects {
    private static String name;
    private static String quantity;
    private static String inStock;

    public static void main(String[] args) {
        while (Run()){
            getProduct();
            Item item = new Item(quantity, name, inStock);
        }
        
        
            System.exit(0);
    }
    
    public static boolean Run() {
        System.out.println("Would you like to create a new object?\n"
                + "Yes or No");
        boolean answer;
        Scanner input = new Scanner(System.in);
        char letter = Character.toLowerCase(input.next().charAt(0));
        return letter == 'y';
        }
    public static void getProduct() {
        System.out.println("What is the name of the product?");
        Scanner input = new Scanner(System.in);
        String name = input.nextLine();
        System.out.println("How much of the product do we have?");
        String quantity = input.nextLine();
        System.out.println("Is the product in stock? Yes or No?");
        String inStock = input.nextLine();
    }
}
