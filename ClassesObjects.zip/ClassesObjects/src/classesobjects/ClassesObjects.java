package classesobjects;

// Author James Jensen

import java.util.*;

public class ClassesObjects {
    private static Scanner input = new Scanner(System.in);
    private static String answer;
    private static String name;
    private static String quantity;
    private static String inStock;

    public static void main(String[] args) {
        while (Run()){
            getProduct();
            try {
                Item item = new Item(quantity, name, inStock);
                System.out.println(item);
            } catch (NumberFormatException e) {
                System.out.println(e);
            } catch (InputMismatchException e) {
                System.out.println(e);
            } catch (IllegalArgumentException e) {
                System.out.println(e);
            } catch (Exception e) {
                System.out.println(e);
            } finally {
                System.out.println("Done");
            }
        }
        
        
            System.exit(0);
    }
    
    public static boolean Run() {
        System.out.println("Would you like to create a new object?\n"
                + "Yes or No");
        boolean answer;
        char letter = Character.toLowerCase(input.next().charAt(0));
        String clear = input.nextLine();
        return letter == 'y';
        }
    public static void getProduct() {
        name = promptAndGet("What is the name of the product?");
        quantity = promptAndGet("What how much of the product do we have?");
        inStock = promptAndGet("Is the product in stock?");
        
            
    }
    
    public static String promptAndGet (String prompt) {
        String answer;
        do {
            System.out.println(prompt);
            answer = input.nextLine().trim();
            
        } while (answer.isBlank());
                return answer;
    }
}
