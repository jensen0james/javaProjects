package classesobjects;

// Author James Jensen

import java.util.*;

public class ClassesObjects {
    private static Scanner input = new Scanner(System.in);
    private static String answer;
    private static String name;
    private static String quantity;
    private static String inStock;

    public static void main(String[] args) {
        while (Run()){
            getProduct();
            Item item = new Item(quantity, name, inStock);
            System.out.println(item.toString());
        }
        
        
            System.exit(0);
    }
    
    public static boolean Run() {
        System.out.println("Would you like to create a new object?\n"
                + "Yes or No");
        boolean answer;
        char letter = Character.toLowerCase(input.next().charAt(0));
        String clear = input.nextLine();
        return letter == 'y';
        }
    public static void getProduct() {
        System.out.println("What is the name of the product?");
        answer = input.nextLine();
        name = dataCheck(answer);
        System.out.println("How much of the product do we have?");
        answer = input.nextLine();
        quantity = dataCheck(answer);
        System.out.println("Is the product in stock? Yes or No?");
        answer = input.nextLine();
        inStock = answer.toLowerCase().substring(0, 1).trim();
        inStock = dataCheck(answer).toLowerCase().substring(0, 1).trim();
        if ("y".equals(inStock))
            inStock = "true";
        else
            inStock = "false";
        
            
    }
    public static String dataCheck(String answer) {
        String data = answer;
        while (data.isBlank()) 
        {
            System.out.println("No data was entered, please try again.");
            data = input.nextLine();
        }
        return data;
    }
}
