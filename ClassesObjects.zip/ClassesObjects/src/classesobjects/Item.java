package classesobjects;

//Author James Jensen

public class Item {
    private int quantity;
    private String name;
    private boolean inStock;


public Item(String quantity, String name, String inStock) {
    this.quantity = Integer.parseInt(quantity);
    this.name = name;
    this.inStock = Boolean.parseBoolean(inStock);

}

@Override
    public String toString() {
        return String.format("Product: %s\n"
                + "Quantity: %d\n"
                + "In Stock: %b\n", name, quantity, inStock);
    }
}

